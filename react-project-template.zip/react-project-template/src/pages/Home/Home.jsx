
const Home = () => {
  return (
    <div className="w-full h-[90vh] text-red-600">Home</div>
  )
}

export default Home